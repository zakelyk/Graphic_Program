# Graphic_Program

Before trying program please install matplotlib on python firstly 

pip install matplotlib
